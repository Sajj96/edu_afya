@extends('layouts.app')


@section('content')
<div class="page-wrapper">
    <div class="content">

        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard </a></li>
                        <li class="breadcrumb-item"><i class="feather-chevron-right"></i></li>
                        <li class="breadcrumb-item active">App Subscriptions</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                @include('flash-message')
                <div class="card-box">
                    <div class="card-block">
                        <div class="page-table-header mb-2">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="doctor-table-blk">
                                        <h3>Subscriptions List</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="datatable table border-0 custom-table comman-table table-stripped ">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Customer Name</th>
                                        <th>Customer Phone</th>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>Payment Status</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($subscriptions as $key=>$subscription)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td><a href="#">{{ $subscription->userName }}</a></td>
                                        <td>{{ $subscription->userPhone }}</td>
                                        <td>{{ $subscription->subscriptionName }}</td>
                                        <td>{{ number_format($subscription->price) }}</td>
                                        <td>
                                            @if($subscription->payments_status == 0)
                                            <span class="custom-badge status-orange">Pending</span>
                                            @else
                                            <span class="custom-badge status-green">Paid</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if($subscription->isActive)
                                            <span class="custom-badge status-green">Active</span>
                                            @else
                                            <span class="custom-badge status-red">Expired</span>
                                            @endif
                                        </td>
                                        <td class="text-end">
                                            @if(!$subscription->isActive)
                                            <a href="#" class="btn btn-success add-pluss ms-2">Activate</a>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection